Cambios del menú FF NORMAL

- Se quitó TEXTURAS de la sección FF NORMAL y se retiró su paquete integrado.
- Se añadieron los controles visuales AMBOT PECHO y BALAS MÁGICAS 20%.
- Los dos controles nuevos son demostrativos: no aplican parches ni modifican Free Fire y se desactivan automáticamente después de 20 segundos.
- Se quitó el subtítulo que aparecía debajo de 3105 en la pantalla de atribución.
