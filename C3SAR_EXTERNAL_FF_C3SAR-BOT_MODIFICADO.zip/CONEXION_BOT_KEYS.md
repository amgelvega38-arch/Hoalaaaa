# Conexión con el bot de Telegram @C3SAR_V1_Bot (keys)

La app valida las keys creadas por el bot contra:
https://project--e653dd5b-62dd-4c0e-95c1-295c343d0053.lovable.app

La dirección está fija dentro de ThreeOneOSFive/App.swift (PantherSession.apiBase),
así que aunque cambies Info.plist, textos, menús o patches, sigue conectada al bot.
Si copias App.swift de otra versión, conserva la línea `private let apiBase = ...`.

- POST /api/public/activate  -> { key, device_id, check }
- La app vuelve a revisar la key cada 5 segundos mientras está abierta.
- BAN KEY: la key se borra; la app sale y muestra "La key no existe.".
- RESET KEY: el celular anterior sale ("La key fue reseteada") y otro celular puede entrar con la misma key.
